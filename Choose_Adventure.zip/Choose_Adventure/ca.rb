require 'chronic'

class User
	attr_accessor :country
	attr_accessor :jesse
	attr_accessor :location
	attr_accessor :money_one
	attr_accessor :purity
	attr_accessor :knocks
	attr_accessor :meeting_time

	def initialize (options = {})
		@country = options[:country]
		@jesse = options[:jesse]
		@location = options[:location]
		@money_one = options[:money_one]
		@purity = options[:purity]
		@knocks = options[:knocks]
		@meeting_time = options[:meeting_time]
	end
end

game_user = User.new

r = Chronic.parse('tomorrow')

def prompt
	print "> "
end

puts "You are a high school chemistry teacher with a wife, a kid, and another on the way."
puts "You just found out that you have lung cancer." 
puts "Where are you located?"
puts "1. USA"
puts "2. Canada"

prompt; game_user.country = gets.chomp

if game_user.country =="1"
	puts "You're naturally devastated."
	puts "You randomly run into a former student and general degenerate, Jesse, on the way to the oncologist. He's running away from... something."
	puts "What do you do?"
	puts "1. Ignore him. You're very disappointed that he hasn't applied himself at all in the years after high school."
	puts "2. You say hi."
	puts "3. You ask him about making meth."

	prompt; game_user.jesse = gets.chomp

	if game_user.jesse == "1"
		puts "You forget about seeing Jesse when you get to the oncologist's office, and you find out the treatment that could prolong your life costs a lot more than your measily teacher's salary can afford."
		puts "However, your wife goes to your former colleagues and friends, Gretchen and Elliott, with stories of your plight. They offer to pay for your treatments."
		puts "What do you do?"
		puts "1. You're still bitter about their screwing you over decades ago, and say no."
		puts "2. You swallow your pride, and accept the money."

		prompt; game_user.money_one = gets.chomp

		if game_user.money_one == "1"
			puts "You end up dying because you couldn't afford treatment. The end."
		elsif game_user.money_one == "2"
			puts "After a couple of months of treatment, your health improves drastically. You are eternally grateful to Gretchen and Elliott, and they invite you back into their billion-dollar company, Grey Matter. You eventually recover and live happily ever after."
		else 
			puts "You don't know how to follow directions and you accidentally take eight pills instead of the directed two and overdose on painkillers. Peace out, dummy."
		end		

	elsif game_user.jesse == "2"
		puts "You guys make awkward small talk for a minute and eventually part ways. You forget about seeing Jesse when you get to the oncologist's office, and you find out the treatment that could prolong your life costs a lot more than your measily teacher's salary can afford."
		puts "However, your wife goes to your former colleagues and friends, Gretchen and Elliott, with stories of your plight. They offer to pay for your treatments."
		puts "What do you do?"
		puts "1. You're still bitter about their screwing you over decades ago, and say no."
		puts "2. You swallow your pride, and accept the money."

		prompt; game_user.money_one = gets.chomp

		if game_user.money_one == "1"
			puts "You end up dying because you couldn't afford treatment. The end."
		elsif game_user.money_one == "2"
			puts "After a couple of months of treatment, your health improves drastically. You are eternally grateful to Gretchen and Elliott, and they invite you back into their billion-dollar company, Grey Matter. You eventually recover and live happily ever after."
		else 
			puts "You don't know how to follow directions and you accidentally take eight pills instead of the directed two and overdose on painkillers. Peace out, dummy."
		end		

	elsif game_user.jesse == "3"
		puts "Jesse reacts with surprise that his straightlaced high school chemistry teacher is asking him such a question."
		puts "You guys decide to talk about things more at a coffeeshop the next day."
		
		game_user.meeting_time = r

		puts "The next day, you both meet and discuss details."
		puts "You spend a week getting ahold of the necessary materials, including an RV."
		puts "You are now ready to cook."
		puts "Where do you go?"
		puts "1. Your basement"
		puts "2. An abandoned lot"
		puts "3. The wide expanse of the New Mexico dessert"

		prompt; game_user.location = gets.chomp

		if game_user.location == "1"
			puts "As much as you tried to protect them against it, your entire family gets sick from the chemicals. The hospital gets suspicious, and calls the police, who inspect your house and find traces of meth production everywhere. You go to jail. The end."
		elsif game_user.location == "2"
			puts "The police know that the abandoned lot is a favorite of criminals of all varieties, and patrol it regularly. They catch you red-handed and you go to jail. The end."
		elsif game_user.location == "3"
			puts "You successfully make your first batch."
			puts "How pure is it? Give a percentage number."

			prompt; game_user.purity = gets.to_i()

			if game_user.purity >= 0 and game_user.purity <= 75
				puts "That's terrible. You'll never sell drugs that way."
				puts "You go back to teaching, and settle for the harsh truth that you will die soon."

			elsif game_user.purity > 75 and game_user.purity < 90
				puts "That's pretty standard. You make a little money, but eventually decide that it isn't worth it."
				puts "You go back to your every day life as a chemistry teacher, and eventually succumb to the cancer. Hey, at least you tried."
				
			elsif game_user.purity >=90 and game_user.purity < 100
				puts "Wow. The likes of your product have not been seen on the streets."
				puts "You start selling a lot of meth."
				puts "Are you the one who knocks?"
				puts "1. Yes"
				puts "2. No"

				prompt; game_user.knocks = gets.chomp

				if game_user.knocks = "1"
					puts "You become the feared drug kingpin, Heisenberg."
					puts "You alienate your entire family, and murder a bunch of people."
					puts "You pretty much have nothing."
					puts "But at least you have money. A dolla make you holla! The bitter end."
				elsif game_user.knocks = "2"
					puts "It's a harsh world out there, bro."
					puts "You don't have what it takes to make it."
					puts "You go back to your life. The end."
				else
					puts "You randomly choke on some fried chicken from Los Pollos Hermanos. Peace out, dummy."
				end

			else
				puts "That's not a percentage, dummy."
			end

		else
			puts "You don't know how to follow directions and you accidentally take eight pills instead of the directed two and overdose on painkillers. Peace out, dummy."
		end			

	else
		puts "You don't know how to follow directions and you accidentally take eight pills instead of the directed two and overdose on painkillers. Peace out, dummy."
	end

		

elsif game_user.country == "2"
	puts "Your treatment starts next week. Socialized medicine ain't so bad. The end."

else
	puts "You are very upset over your cancer diagnosis."
	puts "You decide to hop into Los Pollos Hermanos since you're probably going to die anyway."
	puts " Oh no! You randomly choke on some fried chicken! Learn how to follow directions, dummy."
end

