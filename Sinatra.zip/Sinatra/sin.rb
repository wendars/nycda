require 'sinatra'

get '/hello/:name' do
	"Hello #{params[:name]}"
end

get '/' do
	"Hello stranger"
end

get '/dogg' do
	"Drop it like it's hot. Don't pocket like it's hot though."
end